# Prahari AutoFill App 📱

Field auditors ke liye Prahari center filling automation app.

## Kya karta hai?

1. **CDS photo khicho** → Gemini padhta hai
2. **Verify karo** → Card-missing members confirm karo
3. **Auto-fill** → 10-point rulebook lagke Prahari me save
4. **Chat se rules change karo** → "P4 No kar do"

## Setup

### 1. Dependencies install karo
```bash
cd prahari-autofill-app
npm install
```

### 2. Firebase setup karo
1. [Firebase Console](https://console.firebase.google.com) par naya project banao
2. Authentication → Email/Password enable karo
3. Firestore Database banao (production mode)
4. `src/api/firebase.js` me apni config dalo:
```js
const firebaseConfig = {
  apiKey: 'YOUR_API_KEY',
  authDomain: 'YOUR_PROJECT.firebaseapp.com',
  projectId: 'YOUR_PROJECT_ID',
  ...
};
```

### 3. Gemini API key
1. [Google AI Studio](https://aistudio.google.com) par jao
2. "Get API Key" → Free key banao
3. App me Prahari Connect screen par dalo

### 4. Chalao (testing)
```bash
npx expo start
```
- Phone par **Expo Go** app install karo
- QR code scan karo

### 5. APK banao (real use)
```bash
npm install -g eas-cli
eas login
eas build:configure
eas build --platform android --profile production
```
- APK download karo
- Auditors ko WhatsApp par bhejo!

## Zaroori notes

- ⚠️ **VPN on rakho!** Prahari VPN ke bina nahi khulega
- Prahari password sirf phone me encrypted save hota hai
- Har auditor apni Gemini key lagaye (free tier enough hai)

## Screens

| Screen | Kaam |
|--------|------|
| Login | Firebase login |
| Register | Naya auditor account |
| Prahari Connect | Prahari ID + Gemini key |
| Audit List | Assigned audits |
| Center List | Search + select center |
| CDS Photo | Photo khicho |
| CDS Results | Gemini output verify karo |
| Auto Fill | Automatic 10-point fill |
| Confirmation | Result dekho |
| Chat 💬 | "P4 No kar do" |
| My Rules 📋 | Rules dekho/edit karo |

## Cost: ₹0/month! 🎉
- Firebase free tier
- Gemini free tier
- Koi VPS nahi!
