import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text } from 'react-native';

import LoginScreen from './src/screens/LoginScreen';
import RegisterScreen from './src/screens/RegisterScreen';
import PrahariConnectScreen from './src/screens/PrahariConnectScreen';
import AuditListScreen from './src/screens/AuditListScreen';
import CenterListScreen from './src/screens/CenterListScreen';
import CDSPhotoScreen from './src/screens/CDSPhotoScreen';
import CDSResultsScreen from './src/screens/CDSResultsScreen';
import AutoFillScreen from './src/screens/AutoFillScreen';
import ConfirmationScreen from './src/screens/ConfirmationScreen';
import ChatScreen from './src/screens/ChatScreen';
import MyRulesScreen from './src/screens/MyRulesScreen';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

function FillStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="AuditList" component={AuditListScreen} options={{ title: 'Mere Audits' }} />
      <Stack.Screen name="CenterList" component={CenterListScreen} options={{ title: 'Centers' }} />
      <Stack.Screen name="CDSPhoto" component={CDSPhotoScreen} options={{ title: 'CDS Photo' }} />
      <Stack.Screen name="CDSResults" component={CDSResultsScreen} options={{ title: 'Verify CDS' }} />
      <Stack.Screen name="AutoFill" component={AutoFillScreen} options={{ title: 'Auto Filling...', headerLeft: null }} />
      <Stack.Screen name="Confirmation" component={ConfirmationScreen} options={{ title: 'Done!', headerLeft: null }} />
    </Stack.Navigator>
  );
}

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: () => {
          const icons = { Fill: '📝', Chat: '💬', Rules: '📋' };
          return <Text style={{ fontSize: 24 }}>{icons[route.name]}</Text>;
        },
      })}
    >
      <Tab.Screen name="Fill" component={FillStack} options={{ headerShown: false }} />
      <Tab.Screen name="Chat" component={ChatScreen} options={{ title: 'Rule Chat' }} />
      <Tab.Screen name="Rules" component={MyRulesScreen} options={{ title: 'Mere Rules' }} />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Register" component={RegisterScreen} />
        <Stack.Screen name="PrahariConnect" component={PrahariConnectScreen} />
        <Stack.Screen name="Main" component={MainTabs} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
