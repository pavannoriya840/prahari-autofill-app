import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, FlatList, KeyboardAvoidingView, Platform, ActivityIndicator } from 'react-native';
import { parseChatCommand } from '../api/gemini';
import { firebaseApi, auth } from '../api/firebase';

export default function ChatScreen() {
  const [messages, setMessages] = useState([
    { id: '0', from: 'bot', text: 'Namaste! 🙏\n\nRule change karne ke liye message bhejo:\n\n• "P4 No kar do"\n• "P8 ka remark: [naya text]"\n• "Rules dikhao"\n• "Rules reset karo"' },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { id: `${Date.now()}`, from: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const uid = auth.currentUser?.uid;
      const cmd = await parseChatCommand(userMsg);
      let reply = '';

      if (cmd.action === 'update_rule' && uid) {
        await firebaseApi.updateRule(uid, cmd.point, cmd.field, cmd.value);
        reply = cmd.field === 'default'
          ? `✅ ${cmd.point} ab "${cmd.value}" ho gaya!`
          : `✅ ${cmd.point} ka remark update ho gaya!`;
      } else if (cmd.action === 'show_rules' && uid) {
        const rules = await firebaseApi.getRules(uid);
        reply = '📋 Tumhare Rules:\n\n' + Object.entries(rules || {})
          .filter(([k]) => k.startsWith('P'))
          .map(([k, v]) => `${k}: ${v.default}${v.customRemark ? ` (custom remark)` : ''}`)
          .join('\n');
      } else if (cmd.action === 'reset_rules' && uid) {
        await firebaseApi.resetRules(uid);
        reply = '✅ Saare rules default par reset ho gaye!';
      } else {
        reply = '❓ Samajh nahi aaya. Try karo:\n"P4 No kar do"\n"P8 ka remark: [text]"\n"Rules dikhao"';
      }

      setMessages(prev => [...prev, { id: `${Date.now()}-r`, from: 'bot', text: reply }]);
    } catch (e) {
      setMessages(prev => [...prev, { id: `${Date.now()}-e`, from: 'bot', text: `❌ Error: ${e.message}` }]);
    }
    setLoading(false);
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={100}
    >
      <FlatList
        data={messages}
        keyExtractor={item => item.id}
        style={styles.list}
        renderItem={({ item }) => (
          <View style={[styles.bubble, item.from === 'user' ? styles.userBubble : styles.botBubble]}>
            <Text style={[styles.text, item.from === 'user' && styles.userText]}>{item.text}</Text>
          </View>
        )}
      />
      {loading && <ActivityIndicator style={styles.loading} />}
      <View style={styles.inputRow}>
        <TextInput
          style={styles.input}
          placeholder="e.g. P4 No kar do"
          value={input}
          onChangeText={setInput}
          onSubmitEditing={sendMessage}
        />
        <TouchableOpacity style={styles.send} onPress={sendMessage}>
          <Text style={styles.sendText}>➤</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  list: { flex: 1, padding: 12 },
  bubble: { maxWidth: '80%', borderRadius: 12, padding: 12, marginBottom: 8 },
  userBubble: { backgroundColor: '#2196F3', alignSelf: 'flex-end' },
  botBubble: { backgroundColor: '#fff', alignSelf: 'flex-start', elevation: 1 },
  text: { fontSize: 15 },
  userText: { color: '#fff' },
  loading: { margin: 8 },
  inputRow: { flexDirection: 'row', padding: 12, backgroundColor: '#fff' },
  input: { flex: 1, borderWidth: 1, borderColor: '#ddd', borderRadius: 24, padding: 12, marginRight: 8 },
  send: { backgroundColor: '#2196F3', borderRadius: 24, width: 48, height: 48, justifyContent: 'center', alignItems: 'center' },
  sendText: { color: '#fff', fontSize: 20 },
});
