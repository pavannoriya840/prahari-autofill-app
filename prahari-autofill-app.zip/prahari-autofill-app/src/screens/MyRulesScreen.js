import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, ActivityIndicator, Alert, TextInput, Modal } from 'react-native';
import { firebaseApi, auth } from '../api/firebase';
import { DEFAULT_REMARKS } from '../utils/rulebook';

const POINTS = ['P1','P2','P3','P4','P5','P6','P7','P8','P9','P10'];

export default function MyRulesScreen() {
  const [rules, setRules] = useState(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [editValue, setEditValue] = useState('');

  useEffect(() => { loadRules(); }, []);

  const loadRules = async () => {
    const uid = auth.currentUser?.uid;
    if (uid) {
      const r = await firebaseApi.getRules(uid);
      setRules(r);
    }
    setLoading(false);
  };

  const toggleDefault = async (point) => {
    const uid = auth.currentUser?.uid;
    const current = rules[point]?.default || 'No';
    const newVal = current === 'Yes' ? 'No' : 'Yes';
    await firebaseApi.updateRule(uid, point, 'default', newVal);
    loadRules();
  };

  const saveRemark = async () => {
    const uid = auth.currentUser?.uid;
    await firebaseApi.updateRule(uid, editing, 'customRemark', editValue || null);
    setEditing(null);
    loadRules();
  };

  const handleReset = () => {
    Alert.alert('Reset?', 'Saare rules default par wapas?', [
      { text: 'Cancel' },
      { text: 'Reset', onPress: async () => {
        await firebaseApi.resetRules(auth.currentUser.uid);
        loadRules();
      }},
    ]);
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" /></View>;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>📋 Mere Rules</Text>
      <FlatList
        data={POINTS}
        keyExtractor={p => p}
        renderItem={({ item: point }) => {
          const rule = rules?.[point] || {};
          return (
            <View style={styles.card}>
              <View style={styles.row}>
                <Text style={styles.point}>{point}</Text>
                <TouchableOpacity
                  style={[styles.toggle, rule.default === 'Yes' ? styles.yes : styles.no]}
                  onPress={() => toggleDefault(point)}
                >
                  <Text style={styles.toggleText}>{rule.default || 'No'}</Text>
                </TouchableOpacity>
              </View>
              <Text style={styles.remark} numberOfLines={2}>
                📝 {rule.customRemark || DEFAULT_REMARKS[point] || DEFAULT_REMARKS[point + '_MANY'] || 'Koi remark nahi'}
              </Text>
              <TouchableOpacity onPress={() => { setEditing(point); setEditValue(rule.customRemark || ''); }}>
                <Text style={styles.editLink}>Remark edit karo</Text>
              </TouchableOpacity>
            </View>
          );
        }}
      />
      <TouchableOpacity style={styles.resetButton} onPress={handleReset}>
        <Text style={styles.resetText}>🔄 Reset to Default</Text>
      </TouchableOpacity>

      <Modal visible={!!editing} transparent animationType="slide">
        <View style={styles.modal}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>{editing} ka Remark</Text>
            <TextInput
              style={styles.modalInput}
              multiline
              numberOfLines={4}
              value={editValue}
              onChangeText={setEditValue}
              placeholder="Hindi me remark likho..."
            />
            <View style={styles.modalButtons}>
              <TouchableOpacity style={styles.modalCancel} onPress={() => setEditing(null)}>
                <Text>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.modalSave} onPress={saveRemark}>
                <Text style={styles.modalSaveText}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#f5f5f5' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 16 },
  card: { backgroundColor: '#fff', borderRadius: 10, padding: 14, marginBottom: 10 },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  point: { fontSize: 18, fontWeight: 'bold' },
  toggle: { borderRadius: 16, paddingHorizontal: 16, paddingVertical: 8 },
  yes: { backgroundColor: '#F44336' },
  no: { backgroundColor: '#4CAF50' },
  toggleText: { color: '#fff', fontWeight: 'bold' },
  remark: { color: '#666', fontSize: 13, marginBottom: 6 },
  editLink: { color: '#2196F3' },
  resetButton: { backgroundColor: '#FF9800', borderRadius: 8, padding: 14, alignItems: 'center', marginTop: 10 },
  resetText: { color: '#fff', fontWeight: 'bold' },
  modal: { flex: 1, justifyContent: 'center', backgroundColor: 'rgba(0,0,0,0.5)', padding: 24 },
  modalBox: { backgroundColor: '#fff', borderRadius: 12, padding: 20 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 12 },
  modalInput: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, minHeight: 100, textAlignVertical: 'top' },
  modalButtons: { flexDirection: 'row', justifyContent: 'flex-end', marginTop: 16 },
  modalCancel: { padding: 12, marginRight: 12 },
  modalSave: { backgroundColor: '#4CAF50', borderRadius: 8, padding: 12, paddingHorizontal: 24 },
  modalSaveText: { color: '#fff', fontWeight: 'bold' },
});
