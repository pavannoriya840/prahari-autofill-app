import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, ActivityIndicator, TextInput } from 'react-native';
import { prahariApi } from '../api/prahari';

export default function CenterListScreen({ navigation, route }) {
  const { audit } = route.params;
  const [centers, setCenters] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadCenters(); }, []);

  useEffect(() => {
    if (!search) setFiltered(centers);
    else setFiltered(centers.filter(c =>
      (c.center_code || '').toLowerCase().includes(search.toLowerCase()) ||
      (c.center_name || '').toLowerCase().includes(search.toLowerCase())
    ));
  }, [search, centers]);

  const loadCenters = async () => {
    try {
      const today = new Date().toISOString().split('T')[0];
      // Audit ke centers — API se
      const data = await prahariApi.getCenterDetails(audit.id, today);
      const list = data.centers || data || [];
      setCenters(list);
      setFiltered(list);
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" /></View>;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{audit.branch_name || 'Centers'}</Text>
      <TextInput
        style={styles.search}
        placeholder="Center code/name search karo..."
        value={search}
        onChangeText={setSearch}
      />
      <FlatList
        data={filtered}
        keyExtractor={(item, i) => `${item.center_id || item.id || i}`}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.card}
            onPress={() => navigation.navigate('CDSPhoto', { audit, center: item })}
          >
            <Text style={styles.cardTitle}>{item.center_code}</Text>
            <Text style={styles.cardSub}>{item.center_name}</Text>
            <Text style={styles.cardSub}>📅 {item.meeting_day} {item.meeting_time}</Text>
          </TouchableOpacity>
        )}
        ListEmptyComponent={<Text style={styles.empty}>Koi center nahi mila</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#f5f5f5' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 12 },
  search: { backgroundColor: '#fff', borderRadius: 8, padding: 12, marginBottom: 12, fontSize: 16 },
  card: { backgroundColor: '#fff', borderRadius: 10, padding: 16, marginBottom: 10, elevation: 2 },
  cardTitle: { fontSize: 16, fontWeight: 'bold' },
  cardSub: { color: '#666', marginTop: 2 },
  empty: { textAlign: 'center', color: '#999', marginTop: 40 },
});
