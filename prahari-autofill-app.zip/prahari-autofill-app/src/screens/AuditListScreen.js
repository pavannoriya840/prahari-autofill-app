import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { prahariApi } from '../api/prahari';

export default function AuditListScreen({ navigation }) {
  const [audits, setAudits] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadAudits(); }, []);

  const loadAudits = async () => {
    try {
      const data = await prahariApi.getAudits();
      setAudits(data.audits || data || []);
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" /></View>;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Mere Audits</Text>
      <FlatList
        data={audits}
        keyExtractor={(item, i) => `${item.id || i}`}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.card}
            onPress={() => navigation.navigate('CenterList', { audit: item })}
          >
            <Text style={styles.cardTitle}>{item.branch_name || item.name}</Text>
            <Text style={styles.cardSub}>ID: {item.id} | {item.start_date} - {item.end_date}</Text>
            <Text style={styles.cardSub}>Status: {item.status}</Text>
          </TouchableOpacity>
        )}
        ListEmptyComponent={<Text style={styles.empty}>Koi audit nahi mila</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#f5f5f5' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 16 },
  card: { backgroundColor: '#fff', borderRadius: 10, padding: 16, marginBottom: 12, elevation: 2 },
  cardTitle: { fontSize: 18, fontWeight: 'bold' },
  cardSub: { color: '#666', marginTop: 4 },
  empty: { textAlign: 'center', color: '#999', marginTop: 40 },
});
