import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';

export default function ConfirmationScreen({ navigation, route }) {
  const { center, memberCount, cardMissingCount, answers } = route.params;

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.emoji}>✅</Text>
      <Text style={styles.title}>Center Fill Ho Gaya!</Text>

      <View style={styles.card}>
        <Text style={styles.row}>Center: <Text style={styles.bold}>{center.center_code}</Text></Text>
        <Text style={styles.row}>Name: {center.center_name}</Text>
        <Text style={styles.row}>Members: <Text style={styles.bold}>{memberCount}</Text></Text>
        <Text style={styles.row}>Card Missing: <Text style={styles.bold}>{cardMissingCount}</Text></Text>
        <Text style={styles.row}>Status: <Text style={styles.bold}>DRAFT Saved</Text></Text>
      </View>

      <Text style={styles.sectionTitle}>Answers:</Text>
      {Object.entries(answers || {}).map(([point, ans]) => (
        <View key={point} style={styles.answerRow}>
          <Text style={styles.point}>{point}</Text>
          <Text style={[styles.answer, ans.answer === 'Yes' ? styles.yes : styles.no]}>
            {ans.answer}
          </Text>
        </View>
      ))}

      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('CenterList')}
      >
        <Text style={styles.buttonText}>Next Center →</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#fff' },
  emoji: { fontSize: 60, textAlign: 'center', marginTop: 20 },
  title: { fontSize: 24, fontWeight: 'bold', textAlign: 'center', marginBottom: 20 },
  card: { backgroundColor: '#e8f5e9', borderRadius: 10, padding: 16, marginBottom: 20 },
  row: { fontSize: 16, marginBottom: 6 },
  bold: { fontWeight: 'bold' },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 10 },
  answerRow: { flexDirection: 'row', justifyContent: 'space-between', padding: 10, borderBottomWidth: 1, borderColor: '#eee' },
  point: { fontSize: 16, fontWeight: 'bold' },
  answer: { fontSize: 16, fontWeight: 'bold' },
  yes: { color: '#F44336' },
  no: { color: '#4CAF50' },
  button: { backgroundColor: '#2196F3', borderRadius: 8, padding: 16, alignItems: 'center', marginTop: 24, marginBottom: 40 },
  buttonText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
});
