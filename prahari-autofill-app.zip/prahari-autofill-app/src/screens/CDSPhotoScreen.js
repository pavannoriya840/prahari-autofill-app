import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image, Alert, ActivityIndicator } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { readCDS } from '../api/gemini';

export default function CDSPhotoScreen({ navigation, route }) {
  const { audit, center } = route.params;
  const [photo, setPhoto] = useState(null);
  const [loading, setLoading] = useState(false);

  const takePhoto = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission chahiye', 'Camera permission do');
      return;
    }
    const result = await ImagePicker.launchCameraAsync({ quality: 0.8, base64: false });
    if (!result.canceled) setPhoto(result.assets[0].uri);
  };

  const pickFromGallery = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({ quality: 0.8 });
    if (!result.canceled) setPhoto(result.assets[0].uri);
  };

  const handleReadCDS = async () => {
    if (!photo) {
      Alert.alert('Error', 'Pehle photo lo');
      return;
    }
    setLoading(true);
    try {
      const cdsData = await readCDS(photo);
      navigation.navigate('CDSResults', { audit, center, photo, cdsData });
    } catch (e) {
      Alert.alert('CDS Read Failed', e.message);
    }
    setLoading(false);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>📷 CDS Photo</Text>
      <Text style={styles.center}>{center.center_code} - {center.center_name}</Text>

      {photo && <Image source={{ uri: photo }} style={styles.preview} />}

      <TouchableOpacity style={styles.button} onPress={takePhoto}>
        <Text style={styles.buttonText}>📷 Photo Khicho</Text>
      </TouchableOpacity>
      <TouchableOpacity style={[styles.button, styles.secondary]} onPress={pickFromGallery}>
        <Text style={styles.buttonText}>🖼️ Gallery Se Chuno</Text>
      </TouchableOpacity>

      {photo && (
        <TouchableOpacity style={[styles.button, styles.primary]} onPress={handleReadCDS} disabled={loading}>
          {loading
            ? <ActivityIndicator color="#fff" />
            : <Text style={styles.buttonText}>🤖 CDS Padho (Gemini)</Text>}
        </TouchableOpacity>
      )}
      {loading && <Text style={styles.loading}>CDS padh raha hun...</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#fff', alignItems: 'center' },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 8 },
  center: { color: '#666', marginBottom: 20 },
  preview: { width: 300, height: 400, borderRadius: 10, marginBottom: 20, resizeMode: 'contain' },
  button: { backgroundColor: '#666', borderRadius: 8, padding: 14, width: '100%', alignItems: 'center', marginBottom: 10 },
  secondary: { backgroundColor: '#888' },
  primary: { backgroundColor: '#9C27B0' },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  loading: { marginTop: 10, color: '#9C27B0' },
});
