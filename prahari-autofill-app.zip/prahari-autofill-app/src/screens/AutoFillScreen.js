import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, Alert } from 'react-native';
import * as FileSystem from 'expo-file-system';
import { prahariApi } from '../api/prahari';
import { firebaseApi, auth } from '../api/firebase';
import { calculateAnswers, buildFeedbackItems } from '../utils/rulebook';

const STEPS = [
  'Member count le raha hun...',
  'Disbursement data le raha hun...',
  'Rules apply kar raha hun...',
  'Prahari me save kar raha hun...',
  'Verify kar raha hun...',
];

export default function AutoFillScreen({ navigation, route }) {
  const { audit, center, photo, cdsData, cardMissingMembers } = route.params;
  const [step, setStep] = useState(0);
  const [error, setError] = useState(null);

  useEffect(() => { doFill(); }, []);

  const doFill = async () => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const centerId = center.center_id || center.id;

      // Step 1: Member count (API se!)
      setStep(0);
      const { count: memberCount } = await prahariApi.getMemberCount(centerId, today);

      // Step 2: Disbursement data (P4 Excel ke liye)
      setStep(1);
      const disbData = await prahariApi.getDisbursements(centerId, today);

      // Step 3: Rules lao (Firebase) + Answers calculate karo
      setStep(2);
      const uid = auth.currentUser?.uid;
      const customRules = uid ? await firebaseApi.getRules(uid) : {};
      const photoBase64 = await FileSystem.readAsStringAsync(photo, {
        encoding: FileSystem.EncodingType.Base64,
      });
      const answers = calculateAnswers(memberCount, cardMissingMembers, customRules, photoBase64);

      // Step 4: Save karo
      setStep(3);
      // Checklist map — pehle center details se lao (simplified)
      const checklistMap = {};
      const feedbackItems = buildFeedbackItems(answers, checklistMap);
      await prahariApi.saveCenterFeedback({
        centerId,
        auditId: audit.id,
        branchId: audit.branch_id,
        feedbackItems,
      });

      // Step 5: Verify
      setStep(4);
      await prahariApi.verifyCenterFill(centerId, today);

      // History save karo
      if (uid) {
        await firebaseApi.saveFillHistory(uid, {
          centerCode: center.center_code,
          centerName: center.center_name,
          auditId: audit.id,
          answers: Object.fromEntries(
            Object.entries(answers).map(([k, v]) => [k, v.answer])
          ),
          memberCount,
          cardMissingCount: cardMissingMembers.length,
          status: 'DRAFT_SAVED',
        });
      }

      navigation.replace('Confirmation', {
        center, memberCount,
        cardMissingCount: cardMissingMembers.length,
        answers,
      });
    } catch (e) {
      setError(e.message);
    }
  };

  if (error) {
    return (
      <View style={styles.container}>
        <Text style={styles.error}>❌ Error</Text>
        <Text>{error}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ActivityIndicator size="large" color="#9C27B0" />
      <Text style={styles.step}>{STEPS[step]}</Text>
      <Text style={styles.progress}>Step {step + 1} / {STEPS.length}</Text>
      {STEPS.map((s, i) => (
        <Text key={i} style={[styles.stepItem, i <= step && styles.stepDone]}>
          {i < step ? '✅' : i === step ? '⏳' : '⚪'} {s}
        </Text>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24, backgroundColor: '#fff' },
  step: { fontSize: 18, fontWeight: 'bold', marginTop: 20, textAlign: 'center' },
  progress: { color: '#666', marginTop: 8, marginBottom: 24 },
  stepItem: { fontSize: 14, color: '#999', marginTop: 8 },
  stepDone: { color: '#4CAF50' },
  error: { fontSize: 20, fontWeight: 'bold', color: '#F44336', marginBottom: 12 },
});
