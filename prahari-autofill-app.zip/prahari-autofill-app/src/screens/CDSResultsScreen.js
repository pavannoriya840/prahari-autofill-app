import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Alert, ScrollView } from 'react-native';

export default function CDSResultsScreen({ navigation, route }) {
  const { audit, center, photo, cdsData } = route.params;
  const [members, setMembers] = useState(cdsData.members || []);

  const toggleCardMissing = (index) => {
    const updated = [...members];
    updated[index] = { ...updated[index], card_missing: !updated[index].card_missing };
    setMembers(updated);
  };

  const handleConfirm = () => {
    const cardMissing = members.filter(m => m.card_missing);
    navigation.navigate('AutoFill', {
      audit, center, photo,
      cdsData: { ...cdsData, members },
      cardMissingMembers: cardMissing,
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>✅ Verify Karo</Text>
      <Text style={styles.subtitle}>Gemini ne ye padha — sahi hai?</Text>

      <View style={styles.infoBox}>
        <Text>Center: {cdsData.center_code}</Text>
        <Text>Name: {cdsData.center_name}</Text>
        <Text>Meeting: {cdsData.meeting_day} {cdsData.meeting_time}</Text>
      </View>

      <Text style={styles.sectionTitle}>Members ({members.length})</Text>
      <Text style={styles.hint}>Card missing walo par tap karo ✓</Text>

      <FlatList
        data={members}
        keyExtractor={(_, i) => `${i}`}
        renderItem={({ item, index }) => (
          <TouchableOpacity
            style={[styles.member, item.card_missing && styles.memberFlagged]}
            onPress={() => toggleCardMissing(index)}
          >
            <Text style={styles.memberName}>{item.serial}. {item.name}</Text>
            <Text style={styles.memberStatus}>{item.card_missing ? '🔴 Card Missing' : '⚪ OK'}</Text>
          </TouchableOpacity>
        )}
      />

      <TouchableOpacity style={styles.button} onPress={handleConfirm}>
        <Text style={styles.buttonText}>
          Confirm & Fill ({members.filter(m => m.card_missing).length} card missing)
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  title: { fontSize: 22, fontWeight: 'bold', textAlign: 'center' },
  subtitle: { textAlign: 'center', color: '#666', marginBottom: 16 },
  infoBox: { backgroundColor: '#f0f0f0', borderRadius: 8, padding: 12, marginBottom: 16 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 4 },
  hint: { color: '#888', marginBottom: 12 },
  member: { flexDirection: 'row', justifyContent: 'space-between', padding: 12, borderBottomWidth: 1, borderColor: '#eee' },
  memberFlagged: { backgroundColor: '#ffebee' },
  memberName: { fontSize: 16 },
  memberStatus: { fontSize: 14 },
  button: { backgroundColor: '#4CAF50', borderRadius: 8, padding: 16, alignItems: 'center', marginTop: 16 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
});
