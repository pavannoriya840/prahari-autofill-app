import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import { prahariApi } from '../api/prahari';
import { saveGeminiKey, getGeminiKey } from '../api/gemini';

export default function PrahariConnectScreen({ navigation }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [geminiKey, setGeminiKey] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    checkExisting();
  }, []);

  const checkExisting = async () => {
    const loggedIn = await prahariApi.isLoggedIn();
    const key = await getGeminiKey();
    if (key) setGeminiKey(key);
    if (loggedIn && key) navigation.replace('Main');
  };

  const handleConnect = async () => {
    if (!username || !password) {
      Alert.alert('Error', 'Prahari username/password dalo');
      return;
    }
    if (!geminiKey) {
      Alert.alert('Error', 'Gemini API key dalo (Google AI Studio se free milti hai)');
      return;
    }
    setLoading(true);
    try {
      await prahariApi.login(username, password);
      await saveGeminiKey(geminiKey);
      navigation.replace('Main');
    } catch (e) {
      Alert.alert('Connection Failed', e.message);
    }
    setLoading(false);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>🔗 Prahari Connect</Text>
      <Text style={styles.subtitle}>Ek baar connect karo, phir automatic</Text>

      <Text style={styles.label}>Prahari Username</Text>
      <TextInput style={styles.input} placeholder="e.g. AUDIT_37204" value={username} onChangeText={setUsername} autoCapitalize="characters" />

      <Text style={styles.label}>Prahari Password</Text>
      <TextInput style={styles.input} placeholder="Password" value={password} onChangeText={setPassword} secureTextEntry />

      <Text style={styles.label}>Gemini API Key</Text>
      <TextInput style={styles.input} placeholder="Google AI Studio se free key" value={geminiKey} onChangeText={setGeminiKey} autoCapitalize="none" />
      <Text style={styles.hint}>aistudio.google.com → Get API Key (free)</Text>

      <TouchableOpacity style={styles.button} onPress={handleConnect} disabled={loading}>
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Connect</Text>}
      </TouchableOpacity>

      <Text style={styles.note}>⚠️ VPN on rakho! Prahari VPN ke bina nahi khulega.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 24, backgroundColor: '#fff' },
  title: { fontSize: 24, fontWeight: 'bold', textAlign: 'center', marginBottom: 8 },
  subtitle: { textAlign: 'center', color: '#666', marginBottom: 24 },
  label: { fontWeight: 'bold', marginBottom: 6, marginTop: 12 },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 14, fontSize: 16 },
  hint: { color: '#888', fontSize: 12, marginTop: 4 },
  button: { backgroundColor: '#FF9800', borderRadius: 8, padding: 16, alignItems: 'center', marginTop: 24 },
  buttonText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  note: { textAlign: 'center', color: '#F44336', marginTop: 20 },
});
