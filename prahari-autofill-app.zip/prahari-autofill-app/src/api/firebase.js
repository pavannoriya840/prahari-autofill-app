// Firebase Setup
// Auth + Firestore (users, rules, fill_history)

import { initializeApp } from 'firebase/app';
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  setDoc,
  getDoc,
  collection,
  addDoc,
  serverTimestamp,
} from 'firebase/firestore';

// TODO: Firebase Console se apni config yahan dalo
const firebaseConfig = {
  apiKey: 'AIzaSyAoR6GfmhCFGCQiA-s2rdrY8oCXUDfpads',
  authDomain: 'prhari-autofill.firebaseapp.com',
  projectId: 'prhari-autofill',
  storageBucket: 'prhari-autofill.firebasestorage.app',
  messagingSenderId: '239561870533',
  appId: '1:239561870533:web:05c0adf189c7f0f3c534ac',
  measurementId: 'G-KGXEE5Q3DX',
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

export const firebaseApi = {
  // Register naya auditor
  async register(email, password, profile) {
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    const uid = cred.user.uid;
    await setDoc(doc(db, 'users', uid), {
      name: profile.name,
      prahariUsername: profile.prahariUsername,
      empId: profile.empId,
      phone: profile.phone,
      role: 'auditor',
      isActive: true,
      createdAt: serverTimestamp(),
      lastLogin: serverTimestamp(),
    });
    // Default rules banao
    await setDoc(doc(db, 'rules', uid), {
      P1: { default: 'No', customRemark: null },
      P2: { default: 'No', customRemark: null },
      P3: { default: 'No', customRemark: null },
      P4: { default: 'No', customRemark: null },
      P5: { default: 'No', customRemark: null },
      P6: { default: 'No', customRemark: null },
      P7: { default: 'No', customRemark: null },
      P8: { default: 'Yes', customRemark: null },
      P9: { default: 'Yes', customRemark: null },
      P10: { default: 'No', customRemark: null },
      updatedAt: serverTimestamp(),
    });
    return uid;
  },

  // Login
  async login(email, password) {
    const cred = await signInWithEmailAndPassword(auth, email, password);
    return cred.user.uid;
  },

  async logout() {
    await signOut(auth);
  },

  // User profile lao
  async getProfile(uid) {
    const snap = await getDoc(doc(db, 'users', uid));
    return snap.exists() ? snap.data() : null;
  },

  // User ke custom rules lao
  async getRules(uid) {
    const snap = await getDoc(doc(db, 'rules', uid));
    return snap.exists() ? snap.data() : null;
  },

  // Rule update karo (chat se)
  async updateRule(uid, point, field, value) {
    const rulesRef = doc(db, 'rules', uid);
    const snap = await getDoc(rulesRef);
    const rules = snap.exists() ? snap.data() : {};
    rules[point] = { ...rules[point], [field]: value };
    rules.updatedAt = serverTimestamp();
    rules.updatedVia = 'chat';
    await setDoc(rulesRef, rules, { merge: true });
  },

  // Rules reset karo
  async resetRules(uid) {
    const defaults = {};
    for (const p of ['P1','P2','P3','P4','P5','P6','P7','P8','P9','P10']) {
      defaults[p] = { default: (p === 'P8' || p === 'P9') ? 'Yes' : 'No', customRemark: null };
    }
    defaults.updatedAt = serverTimestamp();
    await setDoc(doc(db, 'rules', uid), defaults);
  },

  // Fill history save karo
  async saveFillHistory(uid, fillData) {
    await addDoc(collection(db, 'fill_history', uid, 'fills'), {
      ...fillData,
      filledAt: serverTimestamp(),
    });
  },
};
