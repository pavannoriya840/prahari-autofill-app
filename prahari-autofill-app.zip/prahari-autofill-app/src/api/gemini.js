// Gemini Vision Integration
// CDS photo reading + Chat command parsing

import { GoogleGenerativeAI } from '@google/generative-ai';
import * as SecureStore from 'expo-secure-store';
import * as FileSystem from 'expo-file-system';

const GEMINI_KEY = 'gemini_api_key';

export async function saveGeminiKey(key) {
  await SecureStore.setItemAsync(GEMINI_KEY, key);
}

export async function getGeminiKey() {
  return SecureStore.getItemAsync(GEMINI_KEY);
}

function getModel(apiKey) {
  const genAI = new GoogleGenerativeAI(apiKey);
  return genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
}

const CDS_PROMPT = `You are reading a Collection Demand Sheet (CDS) from Sonata Microfinance.
This is a field audit document with handwritten Hindi text.

Extract the following in JSON format:
{
  "center_code": "e.g. NER:RRL:03:349",
  "center_name": "e.g. Devnagar2nd",
  "meeting_day": "e.g. Monday",
  "meeting_time": "e.g. 10:00 AM",
  "members": [
    {
      "serial": 1,
      "name": "member name",
      "customer_id": "if visible",
      "card_missing": true/false,
      "card_missing_mark": "describe any tick/cross/handwritten mark indicating card issue"
    }
  ],
  "total_members_visible": 0,
  "notes": "any other relevant observations"
}

Look carefully for:
- Handwritten "कार्ड" (card) notations
- Ticks, crosses, or circles next to member names
- Any member marked as not having received loan card

Return ONLY valid JSON, no other text.`;

/**
 * CDS photo padho
 * @param {string} photoUri - Photo ka local URI
 * @returns {object} Parsed CDS data
 */
export async function readCDS(photoUri) {
  const apiKey = await getGeminiKey();
  if (!apiKey) throw new Error('Gemini API key not set');

  // Photo ko base64 me convert karo
  const base64 = await FileSystem.readAsStringAsync(photoUri, {
    encoding: FileSystem.EncodingType.Base64,
  });

  const model = getModel(apiKey);
  const result = await model.generateContent([
    CDS_PROMPT,
    { inlineData: { data: base64, mimeType: 'image/jpeg' } },
  ]);

  const text = result.response.text();
  // JSON extract karo (markdown code blocks hatake)
  const jsonMatch = text.match(/\{[\s\S]*\}/);
  if (!jsonMatch) throw new Error('Could not parse CDS data');
  return JSON.parse(jsonMatch[0]);
}

const CHAT_PROMPT = `You are a command parser for a field audit app.
The user sends messages in Hindi/Hinglish to change audit fill rules.

Parse the message and return JSON:
{
  "action": "update_rule" | "show_rules" | "reset_rules" | "unknown",
  "point": "P1" to "P10" (if applicable),
  "field": "default" | "customRemark" (if applicable),
  "value": "Yes" | "No" | "remark text" (if applicable)
}

Examples:
- "P4 No kar do" → {"action":"update_rule","point":"P4","field":"default","value":"No"}
- "P7 hamesha Yes" → {"action":"update_rule","point":"P7","field":"default","value":"Yes"}
- "P8 ka remark change karo: बैठक नहीं हो रही" → {"action":"update_rule","point":"P8","field":"customRemark","value":"बैठक नहीं हो रही"}
- "P9 default remark" → {"action":"update_rule","point":"P9","field":"customRemark","value":null}
- "Rules dikhao" → {"action":"show_rules"}
- "Rules reset karo" → {"action":"reset_rules"}

Return ONLY valid JSON.`;

/**
 * Chat message ko parse karo
 * @param {string} message - User ka message
 * @returns {object} Parsed command
 */
export async function parseChatCommand(message) {
  const apiKey = await getGeminiKey();
  if (!apiKey) throw new Error('Gemini API key not set');

  const model = getModel(apiKey);
  const result = await model.generateContent([
    `${CHAT_PROMPT}\n\nUser message: "${message}"`,
  ]);

  const text = result.response.text();
  const jsonMatch = text.match(/\{[\s\S]*\}/);
  if (!jsonMatch) return { action: 'unknown' };
  return JSON.parse(jsonMatch[0]);
}
