// Prahari API Client
// Saari requests phone se direct jayengi (VPN on hona chahiye)

import * as SecureStore from 'expo-secure-store';

const BASE_URL = 'https://prahari.sonataindia.com';
const TOKEN_KEY = 'prahari_jwt_token';
const TOKEN_TIME_KEY = 'prahari_token_time';

// Token 1 hour valid
const TOKEN_VALIDITY = 55 * 60 * 1000;

async function apiCall(endpoint, body = {}) {
  const token = await SecureStore.getItemAsync(TOKEN_KEY);
  if (!token) throw new Error('Not logged in to Prahari');

  const response = await fetch(`${BASE_URL}${endpoint}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token, ...body }),
  });

  if (!response.ok) {
    throw new Error(`API Error: ${response.status}`);
  }
  return response.json();
}

export const prahariApi = {
  // Login — JWT token save karo
  async login(username, password) {
    const response = await fetch(`${BASE_URL}/backend/auth/login/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    const data = await response.json();
    if (data.token || data.access || data.jwt) {
      const token = data.token || data.access || data.jwt;
      await SecureStore.setItemAsync(TOKEN_KEY, token);
      await SecureStore.setItemAsync(TOKEN_TIME_KEY, Date.now().toString());
      return { success: true, user: data.user || data };
    }
    throw new Error(data.message || 'Login failed');
  },

  async logout() {
    await SecureStore.deleteItemAsync(TOKEN_KEY);
    await SecureStore.deleteItemAsync(TOKEN_TIME_KEY);
  },

  async isLoggedIn() {
    const token = await SecureStore.getItemAsync(TOKEN_KEY);
    const timeStr = await SecureStore.getItemAsync(TOKEN_TIME_KEY);
    if (!token || !timeStr) return false;
    // Token expiry check
    if (Date.now() - parseInt(timeStr) > TOKEN_VALIDITY) return false;
    return true;
  },

  // Assigned audits ki list
  async getAudits() {
    return apiCall('/backend/audit/list/');
  },

  // Center details (risk details)
  async getCenterDetails(centerId, asOnDate) {
    return apiCall('/backend/audit/centers/risk-details/', {
      center_id: centerId,
      as_on_date: asOnDate,
    });
  },

  // Member count (hamesha API se, CDS se nahi!)
  async getMemberCount(centerId, asOnDate) {
    const data = await apiCall('/backend/audit/customers/risk-details/', {
      center_id: centerId,
      as_on_date: asOnDate,
    });
    const risks = data.customer_risks || data.customers || [];
    return { count: risks.length, members: risks };
  },

  // Disbursement data (P4 Excel ke liye)
  async getDisbursements(centerId, asOnDate) {
    return apiCall('/backend/audit/centers/disbursements/', {
      center_id: centerId,
      as_on_date: asOnDate,
    });
  },

  // Center fill save karo
  async saveCenterFeedback({ centerId, auditId, branchId, feedbackItems }) {
    return apiCall('/backend/audit/center-feedback/save/', {
      center_id: centerId,
      audit_id: auditId,
      branch_id: branchId,
      action: 'DRAFT_SAVED',
      feedback_items: feedbackItems,
    });
  },

  // Verify — save ke baad re-read karo
  async verifyCenterFill(centerId, asOnDate) {
    return apiCall('/backend/audit/centers/risk-details/', {
      center_id: centerId,
      as_on_date: asOnDate,
    });
  },
};
