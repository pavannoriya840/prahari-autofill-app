// 10-Point Rulebook Logic
// Har point ka default answer, conditions, Hindi remarks

export const CHECKLIST_CODES = {
  P1: 'CCP_001', P2: 'CCP_002', P3: 'CCP_003', P4: 'CCP_004', P5: 'CCP_005',
  P6: 'CCP_006', P7: 'CCP_007', P8: 'CCP_008', P9: 'CCP_009', P10: 'CCP_010',
};

// Default rulebook (Firebase se override ho sakta hai)
export const DEFAULT_RULES = {
  P1:  { default: 'No',  remark: null },
  P2:  { default: 'No',  remark: null },
  P3:  { default: 'No',  remark: null },
  P4:  { default: 'No',  remark: null },  // Yes sirf jab card-missing mile
  P5:  { default: 'No',  remark: null },
  P6:  { default: 'No',  remark: null },
  P7:  { default: 'No',  remark: null },  // Yes jab members > 2
  P8:  { default: 'Yes', remark: null },  // Hamesha Yes
  P9:  { default: 'Yes', remark: null },  // Hamesha Yes
  P10: { default: 'No',  remark: null },
};

// Default Hindi remarks
export const DEFAULT_REMARKS = {
  P7: 'केंद्र विजिट के दौरान देखा गया कि स्टाफ केन्द्र मीटिंग के समय से 15 मिनिट विलम्ब से केन्द्र में गया l',
  P8_FEW: 'केंद्र विजिट के दौरान देखा गया की केंद्र में बेठक नहीं लगाई जा रही है सभी सदस्यों के घर जाकर किस्तों की वसूली की जा रही है l',
  P8_MANY: 'विजिट के दौरान देखा गया की सेंटर मीटिंग में 80% सदस्याओं की उपस्थिति नहीं पाई गई l एवं बी आर ओ के द्वारा अनुपस्थित सदस्यों का फॉलो अप नहीं किया जा रहा है l',
  P9: 'केंद्र विजिट के दौरान देखा गया की केंद्र की सदस्याओ को कंपनी के बीमा ब्याज व टोल फ्री नंबर के बारे में जानकारी का अभाव पाया गया l',
};

/**
 * 10 points ke answers calculate karo
 * @param {number} memberCount - API se member count
 * @param {array} cardMissingMembers - Gemini se card-missing list
 * @param {object} customRules - Firebase se user ke custom rules
 * @param {string} cdsPhotoBase64 - CDS photo (evidence ke liye)
 */
export function calculateAnswers(memberCount, cardMissingMembers, customRules = {}, cdsPhotoBase64 = null) {
  const rules = { ...DEFAULT_RULES, ...customRules };
  const answers = {};

  // P1, P2, P3, P5, P6, P10 — default No (custom rule se override)
  for (const p of ['P1', 'P2', 'P3', 'P5', 'P6', 'P10']) {
    answers[p] = {
      answer: rules[p]?.default || 'No',
      remark: rules[p]?.default === 'Yes' ? (rules[p]?.customRemark || null) : null,
      evidence: null,
    };
  }

  // P4 — Card missing
  if (cardMissingMembers && cardMissingMembers.length > 0) {
    answers.P4 = {
      answer: 'Yes',
      remark: rules.P4?.customRemark || null,
      evidence: 'EXCEL',  // Loan_Card Excel auto-generate hoga
      cardMissingMembers,
    };
  } else {
    answers.P4 = {
      answer: rules.P4?.default || 'No',
      remark: null,
      evidence: null,
    };
  }

  // P7 — Late staff (members > 2)
  if (memberCount > 2) {
    answers.P7 = {
      answer: 'Yes',
      remark: rules.P7?.customRemark || DEFAULT_REMARKS.P7,
      evidence: cdsPhotoBase64 ? { type: 'CDS_PHOTO', data: cdsPhotoBase64 } : null,
    };
  } else {
    answers.P7 = {
      answer: rules.P7?.default === 'Yes' ? 'Yes' : 'No',
      remark: rules.P7?.default === 'Yes' ? (rules.P7?.customRemark || DEFAULT_REMARKS.P7) : null,
      evidence: null,
    };
  }

  // P8 — Hamesha Yes
  const p8Remark = rules.P8?.customRemark ||
    (memberCount <= 3 ? DEFAULT_REMARKS.P8_FEW : DEFAULT_REMARKS.P8_MANY);
  answers.P8 = {
    answer: rules.P8?.default || 'Yes',
    remark: p8Remark,
    evidence: cdsPhotoBase64 ? { type: 'CDS_PHOTO', data: cdsPhotoBase64 } : null,
  };

  // P9 — Hamesha Yes, NO evidence
  answers.P9 = {
    answer: rules.P9?.default || 'Yes',
    remark: rules.P9?.customRemark || DEFAULT_REMARKS.P9,
    evidence: null,
  };

  return answers;
}

/**
 * Prahari API ke liye feedback_items format banao
 */
export function buildFeedbackItems(answers, checklistMap) {
  return Object.keys(CHECKLIST_CODES).map(point => {
    const code = CHECKLIST_CODES[point];
    const ans = answers[point];
    const checklist = checklistMap[code] || {};

    return {
      checklist_id: checklist.id || code,
      parameter_code: code,
      answer: ans.answer,
      normal_remark: ans.answer === 'Yes' ? (ans.remark || '') : '',
      evidence_image: ans.evidence?.type === 'CDS_PHOTO'
        ? {
            base64: `data:image/jpeg;base64,${ans.evidence.data}`,
            filename: 'cds.jpg',
            latitude: null,
            longitude: null,
            image_text: null,
          }
        : null,
      // Excel evidence P4 ke liye alag se handle hoga
    };
  });
}
